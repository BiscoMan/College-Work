export class Device {
    model: string;
    friendlyName: string;
    username: string;
    serialNumber: number;
    deviceType: number;
}
