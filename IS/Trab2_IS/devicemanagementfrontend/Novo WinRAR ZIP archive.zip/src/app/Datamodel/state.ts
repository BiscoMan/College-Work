export class State {
    SerialNumber: number;
    state: number;
    error: number;
    energyProduction: number;
}