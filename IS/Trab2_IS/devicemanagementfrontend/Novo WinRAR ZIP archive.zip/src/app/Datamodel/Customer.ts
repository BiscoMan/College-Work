export class Customer {

    userName: string;
    name: string;
    telephone: number;
    residence: string;
}